 <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">

    </div>
</body>
</html>
